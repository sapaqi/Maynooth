Maynooth DZ — updates since the previous ZIP (29 September 2026)

This is an incremental package relative to Maynooth-updates-2026-09-29-GitHub.zip. It contains files changed after that package was prepared (site source commit 8f21c15615ca04fbb8cbff67d68fa497ed9333e7).

Apply in order:
1. Ensure your repository already includes the contents of the previous ZIP.
2. Extract this ZIP and copy its `dist` folder over the repository's `dist` folder, preserving paths and replacing the existing files.
3. Review, commit, and push the changes to GitHub.

Includes: Take Action homepage layout, mobile menu, updated map image, and the wider-screen map height refinements. No files were deleted. The supplied image is 2048 x 1327 pixels despite "5000px" in its original filename.
